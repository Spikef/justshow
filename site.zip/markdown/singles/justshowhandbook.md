# 快捷手册

## show init <name>

初始化一个网站。

## show start -p port

启动网站服务。

## show build

生成网站静态文件。