# Binary模块 #

该模块主要为了解决JS操作二进制文件的需求，将对二进制数据的操作转换为对普通数组的操作。

## bytes构造函数 ##
构造一个字节数组对象，方法如下：new Bytes(input, type)。

``` javascript
	var Bytes = require('binary').bytes;
	var bytes = new Bytes('SUlTTk9EReahhuaetg==', 'base64');
```

input：字符串，字节数组，省略

type：当input为字符串类型时，需要指定

	-- base64: 使用base64字符串构造字节数组
	-- binary: 使用二进制对象构造字节数组
	-- file: 直接读取指定文件内容构造字节数组，此时input为一个文件的绝对路径
	-- 省略： 直接将输入的字符串转为字节数组，此时type表示的是字符串的编码(charset)


注意：字节数组可以使用 for i 循环遍历，不能使用 for in 循环遍历。

## bytes.join(separator) ##
返回以指定分割符合并字节数组后得到的字符串，不改变bytes自身。

## bytes.push(item) ##
将元素追加到字节数组当中。

## bytes.concat(array) ##
将一个字节数组或者普通数组的元素追加到当前字节数组末尾。

## bytes.toArray() ##
返回一个普通数组，包含字节数组中所有字节。

## bytes.toString() ##
如果bytes对象为utf-8格式的字符串构造，则该方法可以正确返回原始字符串。

## bytes.toBase64() ##
返回将字节数组进行base64编码后的值。

## bytes.read(filename, start, size) ##
从指定文件读取内容到字节数组。start：起始字节，size：读取的字节数。

## bytes.save(filename) ##
将字节数组保存至文件。

## bytes.isByteArray() ##
判断是否准确的字节数组，即每一个元素都在[0, 255]这个范围。如果满足条件，则返回-1；否则返回第一个不满足条件的对象的索引。

## 代码示例 ##

``` javascript
	var Bytes = require('binary').bytes;
	var bytes = new Bytes(path.resolve(__dirname, '1.txt'));

	// 进行字节操作
	var byt1 = [], byt2 = [];
	for (var i=0; i<bytes.length; i++) {
		if ( i < 7) {
			byt1.push(bytes[i]);
		}else {
			byt2.push(bytes[i]);
		}
	}
	bytes = byt2.concat(byt1);

	binary.save(path.resolve(__dirname, '2.txt'), bytes);
```

## stream ##
stream提供了一系列方法来增强对二进制数据binary对象的操作。

## stream.read(filename, start, size) ##
从指定文件读取binary。start：起始字节，size：读取的字节数。

## stream.save(filename) ##
将binary保存至文件。

## stream.combine(bin1, bin2, ...) ##
将多个binary合并成一个binary。

## stream.choose(bin, start, size) ##
选取binary中的一部分。start：起始字节，size：读取的字节数。

## stream.toString(bin, charset) ##
binary转字符串。

## stream.byString(str, charset) ##
字符串转binary。

## stream.toBase64(bin) ##
binary转base64。

## stream.byBase64(str) ##
base64转binary。

## stream.toHex(bin) ##
binary转16进制字符串。

## stream.byHex(hex) ##
16进制字符串转binary。

## stream.toBytes(bin) ##
binary转字节数组。

## stream.byBytes(byt) ##
字节数组转binary。

## 代码示例 ##

## 代码示例 ##

## 代码示例 ##

## 代码示例 -4 ##

## 代码示例 ##

``` javascript
	var fs = require('fs');
	var stream = require('binary').stream;

	var pic = fs.readFileSync(path.resolve(__dirname, '1.jpg'));

	var p1 = stream.choose(pic, 0, 40);
	var p2 = stream.choose(pic, 40);
	stream.save(path.resolve(__dirname, '1.prt'), p1);
	stream.save(path.resolve(__dirname, '2.prt'), p2);

	var p3 = stream.combine(p1, p2);
	stream.save(path.resolve(__dirname, '2.jpg'), p3);
```